const express = require('express')
const cors = require('cors')
const Users = require('./users/model')

const server = express()

server.use(express.json())
server.use(cors())

server.post('/api/users', async (req, res) => {
  try {
    const { name, bio } = req.body
    if (!name || !bio) {
      return res.status(400).json({ message: 'Lütfen kullanıcı için bir name ve bio sağlayın' })
    }
    const newUser = await Users.insert({ name, bio })
    return res.status(201).json(newUser)
  } catch (err) {
    return res.status(500).json({ message: 'Veritabanına kaydedilirken bir hata oluştu' })
  }
})

server.get('/api/users', async (req, res) => {
  try {
    const users = await Users.find()
    return res.json(users)
  } catch (err) {
    return res.status(500).json({ message: 'Kullanıcı bilgileri alınamadı' })
  }
})

server.get('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params
    const user = await Users.findById(id)
    if (!user) {
      return res.status(404).json({ message: "Belirtilen ID'li kullanıcı bulunamadı" })
    }
    return res.json(user)
  } catch (err) {
    return res.status(500).json({ message: 'Kullanıcı bilgisi alınamadı' })
  }
})

server.delete('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params
    const deleted = await Users.remove(id)
    if (!deleted) {
      return res.status(404).json({ message: 'Belirtilen ID li kullanıcı bulunamadı' })
    }
    return res.json(deleted)
  } catch (err) {
    return res.status(500).json({ message: 'Kullanıcı silinemedi' })
  }
})

server.put('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params
    const changes = req.body
    if (!changes.name || !changes.bio) {
      return res.status(400).json({ message: 'Lütfen kullanıcı için name ve bio sağlayın' })
    }
    const updated = await Users.update(id, changes)
    if (!updated) {
      return res.status(404).json({ message: "Belirtilen ID'li kullanıcı bulunamadı" })
    }
    return res.json(updated)
  } catch (err) {
    return res.status(500).json({ message: 'Kullanıcı bilgileri güncellenemedi' })
  }
})

module.exports = server
